# AI Creative Prompts
1. Modern enterprise dashboard UI, sleek minimalist style, slate navy and indigo accents, high detail --ar 16:9
2. High-end software workspace, natural light, professional aesthetic --ar 16:9
