# Photography Standards
- Clean, natural light setups with balanced contrast.
- Focus on authentic workspaces, modern software environments, and human interaction.
