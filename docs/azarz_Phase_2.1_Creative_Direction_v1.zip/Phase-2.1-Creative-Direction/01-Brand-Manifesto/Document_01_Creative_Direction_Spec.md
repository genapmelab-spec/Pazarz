# Creative Direction Document 01

Detailed specifications and standards for Pazarz Phase 2.1 Creative Direction deliverable #1.
