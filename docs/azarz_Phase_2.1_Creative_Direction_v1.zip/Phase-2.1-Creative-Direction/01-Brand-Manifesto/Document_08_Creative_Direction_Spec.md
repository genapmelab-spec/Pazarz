# Creative Direction Document 08

Detailed specifications and standards for Pazarz Phase 2.1 Creative Direction deliverable #8.
