# Visual Identity System
- Primary Color: Slate Navy (#1E293B)
- Accent Color: Indigo Silk (#6366F1)
- Neutral Backgrounds: Off-white (#FAFAFA), Slate 900 (#0F172A)
- Typography: Inter / System Sans-Serif
