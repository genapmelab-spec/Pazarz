# Creative Direction Document 18

Detailed specifications and standards for Pazarz Phase 2.1 Creative Direction deliverable #18.
