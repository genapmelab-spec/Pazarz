# Grid Layout & Spatial Rules
- 8pt Spatial Grid system across all UI/UX deliverables.
- Flexible responsive layout containers: 1200px max content width.
