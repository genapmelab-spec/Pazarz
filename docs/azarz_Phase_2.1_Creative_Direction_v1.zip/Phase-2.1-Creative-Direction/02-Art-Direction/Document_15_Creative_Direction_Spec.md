# Creative Direction Document 15

Detailed specifications and standards for Pazarz Phase 2.1 Creative Direction deliverable #15.
