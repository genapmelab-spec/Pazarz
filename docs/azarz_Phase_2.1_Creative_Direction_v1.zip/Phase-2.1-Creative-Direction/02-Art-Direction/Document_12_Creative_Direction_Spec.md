# Creative Direction Document 12

Detailed specifications and standards for Pazarz Phase 2.1 Creative Direction deliverable #12.
